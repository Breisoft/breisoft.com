export { default } from './Team';
